public class Dag {

    int nummer;

    Dag(int nummer) {
        this.nummer = nummer;
    }

    public String toString(){
        return nummer + "";
    }
}
